package Controller;

public enum UserError {
    SUCCESS,
    USERNAME_EXISTS,
    USERNAME_NOT_FOUND,
    WEAK_PASSWORD,
    WRONG_PASSWORD,

}
